#!/usr/bin/env python3
import json
import subprocess
import sys
import time

def get_cpu_usage():
    try:
        with open("/proc/stat", "r") as f:
            fields = [float(column) for column in f.readline().strip().split()[1:]]
        idle, total = fields[3], sum(fields)
        time.sleep(0.05)
        with open("/proc/stat", "r") as f:
            fields2 = [float(column) for column in f.readline().strip().split()[1:]]
        idle2, total2 = fields2[3], sum(fields2)
        diff_total = total2 - total
        diff_idle = idle2 - idle
        if diff_total == 0:
            return 0
        return int((1.0 - (diff_idle / diff_total)) * 100)
    except Exception:
        return 0

def get_ram_usage():
    try:
        with open("/proc/meminfo", "r") as f:
            lines = f.readlines()
        mem_total = 0
        mem_available = 0
        for line in lines:
            if line.startswith("MemTotal:"):
                mem_total = int(line.split()[1])
            elif line.startswith("MemAvailable:"):
                mem_available = int(line.split()[1])
        if mem_total == 0:
            return 0.0, 16.0
        total_gb = mem_total / 1024 / 1024
        avail_gb = mem_available / 1024 / 1024
        used_gb = total_gb - avail_gb
        return used_gb, total_gb
    except Exception:
        return 0.0, 16.0

def get_layout():
    try:
        out = subprocess.check_output(["niri", "msg", "--json", "keyboard-layouts"], stderr=subprocess.DEVNULL)
        data = json.loads(out)
        names = data.get("names", [])
        current_idx = data.get("current_idx", 0)
        if names:
            return names[current_idx]
    except Exception:
        pass
    return "English"

def get_clipboard():
    try:
        out = subprocess.check_output(["wl-paste", "-n"], stderr=subprocess.DEVNULL)
        text = out.decode("utf-8", errors="ignore").strip()
        text = text.replace("\n", " ").replace("\r", "")
        if len(text) > 30:
            return f'"{text[:27]}..."'
        return f'"{text}"' if text else "empty"
    except Exception:
        pass
    return "empty"

def main():
    if len(sys.argv) < 2:
        sys.exit(1)
    
    module_type = sys.argv[1]
    
    # Calculate stats
    cpu = get_cpu_usage()
    ram_used, ram_total = get_ram_usage()
    ram_pct = int((ram_used / ram_total) * 100) if ram_total > 0 else 0
    layout = get_layout()
    clip = get_clipboard()
    
    # HP Bar represents CPU Health (100 - CPU usage)
    hp_val = max(0, 100 - cpu)
    hp_bar_len = 10
    hp_filled = int((hp_val / 100) * hp_bar_len)
    hp_bar = "[" + "|" * hp_filled + " " * (hp_bar_len - hp_filled) + "]"

    # Format Undertale/Deltarune Stat Box
    tooltip_lines = [
        "  * KRIS STATS *",
        "  LV: 1",
        f"  HP: {hp_bar} {hp_val}/100",
        "",
        "  * HARDWARE *",
        f"  CPU: {cpu}%",
        f"  RAM: {ram_used:.1f}G / {ram_total:.1f}G ({ram_pct}%)",
        "",
        "  * SYSTEM *",
        f"  KEYBOARD: {layout}",
        f"  CLIPBOARD: {clip}"
    ]
    tooltip = "\n".join(tooltip_lines)

    layout_short = "EN"
    if "ukrainian" in layout.lower():
        layout_short = "UA"
    elif "english" in layout.lower():
        layout_short = "EN"
    else:
        layout_short = layout[:2].upper()

    labels = {
        "sound": "⚔ SOUND",
        "stats": "♥ STATS",
        "update": "★ UPDATE",
        "lang": f"✦ {layout_short}",
        "clip": "♣ CLIPBOARD",
        "notify": "♠ NOTIFY"
    }
    text = labels.get(module_type, "⚔ ACTION")

    # Output JSON for Waybar
    print(json.dumps({
        "text": text,
        "tooltip": tooltip
    }))

if __name__ == "__main__":
    main()
