# Модуль конфігурації програмного забезпечення.
# Тут вказується перелік системних пакетів, доступних усім користувачам.

{ config, pkgs, ... }:

{
  environment.systemPackages = with pkgs; [
    # --- Графічне середовище та оболонка ---
    niri                  # Віконний менеджер (Wayland compositor)
    waybar                # Панель завдань для Wayland
    networkmanagerapplet  # Аплет мережі для системного трею (nm-applet)
    wofi                  # Запуск програм (Application launcher)

    # --- Термінал та інструменти розробки ---
    kitty                 # Емулятор термінала
    zed-editor            # Швидкий сучасний текстовий редактор
    git                   # Система контролю версій
    wget                  # Завантажувач файлів з мережі
    curl                  # Інструмент передачі даних по мережі
    e2fsprogs             # Утиліти для роботи з атрибутами файлових систем (chattr, lsattr)
    jq                    # Утиліта для парсингу JSON (потрібна для скриптів робочих просторів)
    python3               # Інтерпретатор Python (потрібен для скриптів робочих просторів)
    gcc                   # Компілятор C/C++ (g++, gcc)
    nasm                  # Асемблер NASM (потрібен для розробки на ASM)
    clang-tools           # Набір інструментів Clang (включає clangd для C++ LSP)
    gnumake               # Інструмент автоматизації збирання Make
    gdb                   # Налагоджувач GDB (потрібен для дебагу C/C++ у Zed)
    nodejs                # Середовище виконання JavaScript (Node.js)
    rustc                 # Компілятор Rust
    cargo                 # Пакетний менеджер Rust
    rust-analyzer         # Мовний сервер (LSP) для Rust

    # --- Файловий менеджер ---
    file-roller           # Менеджер архівів
    zip                   # Створення ZIP-архівів
    unzip                 # Розпакування ZIP-архівів
    p7zip                 # Робота з 7z-архівами
    unrar                 # Розпакування RAR-архівів

    # --- Веб-браузер ---
    (chromium.override {
      commandLineArgs = [
        "--ozone-platform-hint=auto"
        "--enable-features=WaylandWindowDecorations"
      ];
    })              # Швидкий класичний браузер Chromium (нативна підтримка Wayland)

    # --- Месенджери та соцмережі ---
    telegram-desktop      # Клієнт Telegram
    vesktop               # Discord-клієнт з Vencord та нативною підтримкою Wayland screen sharing
    viber                 # Месенджер Viber

    # --- Ігри та лаунчери ---
    # Пакет steam прибрано звідси, оскільки він увімкнений системним модулем у systems.nix
    heroic                # Launcher для ігор Epic Games/GOG/Amazon
    prismlauncher         # Лаунчер Minecraft
    protonup-qt           # Керування версіями Proton-GE для Steam
    protontricks          # Менеджер префіксів Proton для налаштування ігор Steam

    # --- Графічні редактори ---
    gimp                  # Графічний редактор GIMP
    krita                 # Графічний редактор Krita
    davinci-resolve       # Редактор відео DaVinci Resolve

    # --- Медіа та звук ---
    obs-studio            # Запис та трансляція відео OBS
    easyeffects           # Ефекти звуку для PipeWire
    pavucontrol           # Графічний мікшер гучності PulseAudio/PipeWire (Volume Control)
    pulseaudio            # Надає pactl для стабільності аудіо-потоків у Steam
    handbrake             # Конвертер та стискач відео HandBrake
    vlc                   # Медіаплеєр VLC

    # --- Офіс ---
    onlyoffice-desktopeditors # Офісний пакет OnlyOffice

    # --- Системні утиліти ---
    btop                  # Моніторинг системи
    fastfetch             # Вивід інформації про систему
    ascii-image-converter # Конвертер зображень в ASCII-арт
    qbittorrent           # Торрент-клієнт
    video-downloader      # Завантажувач відео з YouTube
    yt-dlp                # Консольний завантажувач медіа з YouTube
    rpi-imager            # Офіційна утиліта запису та налаштування SD-карт Raspberry Pi
    baobab                # Графічний аналізатор використання диска (візуальні діаграми папок)
    czkawka               # Сучасний швидкий GUI клінер файлів, дублікатів та Завантажень (містить Krokiet)

    # --- Wayland-утиліти ---
    xwayland              # Прошарок сумісності для X11 додатків у Wayland (потрібен для Steam)
    xwayland-satellite    # Інтеграція Xwayland для Niri
    xsettingsd            # Постійний демонічний утримувач X11-сервера
    grim                  # Скріншотер для Wayland
    slurp                 # Вибір області екрана для скріншотів
    satty                 # Редактор та анотатор скріншотів
    wl-clipboard          # Утиліта роботи з буфером обміну Wayland (wl-copy/wl-paste)
    cliphist              # Менеджер історії буфера обміну для Wayland
    swaynotificationcenter # Демон сповіщень для Wayland з плавними анімаціями (Swaync)

    # --- Іконки ---
    papirus-icon-theme    # Набір красивих плоских іконок для провідника

    # --- Шпалери ---
    linux-wallpaperengine # Програвач живих шпалер з Steam Wallpaper Engine
    hyprpaper             # Утиліта для встановлення статичних шпалер у Wayland
  ];

  # --- Оптимізований Steam з системними мережевими бібліотеками (аналог steam-native) ---
  programs.steam = {
    enable = true;
    remotePlay.openFirewall = true;
    dedicatedServer.openFirewall = true;
    localNetworkGameTransfers.openFirewall = true;
    extraPackages = with pkgs; [
      openssl
      libnghttp2
      gnutls
      curl
      zlib
      util-linux
    ];
  };

}
