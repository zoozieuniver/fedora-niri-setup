# Головний файл конфігурації NixOS.
# Імпортує всі модулі та задає базові системні налаштування.

{ config, pkgs, ... }:

{
  imports = [
    ./hardware-configuration.nix
    ./locale.nix
    ./users.nix
    ./programs.nix
    ./hardware.nix
    ./systems.nix  # Системні служби, портали, PipeWire, nix-ld, стилізація
  ];

  # --- Завантажувач ---
  boot.loader.systemd-boot.enable = false;
  boot.loader.grub = {
    enable = true;
    device = "nodev";
    efiSupport = true;
    useOSProber = true;
  };
  boot.loader.efi.canTouchEfiVariables = true;
  boot.kernelPackages = pkgs.linuxPackages_latest;

  # --- Мережа ---
  networking.hostName = "nixos";
  # Додано публічні резервні DNS, щоб системні програми не висли при збоях AdGuard/WARP
  networking.nameservers = [ "192.168.88.42" "1.1.1.1" "8.8.8.8" ];
  networking.networkmanager.enable = true;
  networking.firewall.allowedTCPPorts = [ 25565 ];
  networking.firewall.allowedUDPPorts = [ 25565 ];
  networking.firewall.checkReversePath = "loose";
  networking.firewall.trustedInterfaces = [ "tailscale0" ];

  # Вимикаємо IPv6 для запобігання таймаутам DNS у FHS-програмах (Steam / Antigravity)
  boot.kernel.sysctl = {
    "net.ipv6.conf.all.disable_ipv6" = 1;
    "net.ipv6.conf.default.disable_ipv6" = 1;
  };

  # --- Дозволи ---
  nixpkgs.config.allowUnfree = true;
  nixpkgs.config.permittedInsecurePackages = [ "pnpm-10.29.2" ];
  nix.settings.experimental-features = [ "nix-command" "flakes" ];
  nix.settings.auto-optimise-store = true;
  
  # --- Автоматичне очищення системи від сміття ---
  nix.gc = {
    automatic = true;
    dates = "weekly";
    options = "--delete-older-than 7d";
  };

  # --- Оптимізація оперативної пам'яті (стиснення холодних сторінок) ---
  zramSwap.enable = true;

  # --- Шрифти ---
  fonts = {
    packages = with pkgs; [
      monocraft
      noto-fonts-color-emoji
      noto-fonts-cjk-sans
    ];
    fontconfig = {
      defaultFonts = {
        monospace = [ "Determination" "Minecraft" "Monocraft" "Noto Color Emoji" "Noto Sans CJK SC" ];
        sansSerif = [ "Determination" "Minecraft" "Monocraft" "Noto Color Emoji" "Noto Sans CJK SC" ];
        serif = [ "Determination" "Minecraft" "Monocraft" "Noto Color Emoji" "Noto Sans CJK SC" ];
      };
    };
  };

  environment.variables = {
    RUST_SRC_PATH = "${pkgs.rustPlatform.rustcSrc}/library";
  };

  # --- Gamescope мікро-композитор для ігор ---
  programs.gamescope.enable = true;

  # --- Налаштування Thunar та його плагінів ---
  programs.thunar = {
    enable = true;
    plugins = with pkgs.xfce; [
      thunar-archive-plugin
    ];
  };

  # --- VPN-клієнт Cloudflare WARP ---
  services.cloudflare-warp.enable = true;
  systemd.services.cloudflare-warp.serviceConfig = {
    PrivateTmp = false;
    ProtectHome = false;
    ProtectSystem = false;
    ProtectControlGroups = false;
    ProtectKernelModules = false;
    ProtectKernelTunables = false;
  };

  system.stateVersion = "26.05";
}
