# Модуль системних служб та утиліт.
# Тут налаштовуються фонові сервіси, портали, сумісність та віртуалізація.

{ config, pkgs, lib, ... }:

{

  # --- Оптимізація TCP буферів та BBR для Гігабітної мережі (700-900+ Мбіт/с у Steam) ---
  boot.kernel.sysctl = {
    "net.core.default_qdisc" = "fq";
    "net.core.rmem_max" = 16777216;
    "net.core.wmem_max" = 16777216;
    "net.ipv4.tcp_rmem" = "4096 87380 16777216";
    "net.ipv4.tcp_wmem" = "4096 65536 16777216";
    "net.core.netdev_max_backlog" = 10000;
  };

  # --- Оптимізація мережевої карти для Гігабітного каналу після Windows (DualBoot) ---
  boot.kernelParams = [ "pcie_aspm=off" ];

  systemd.services."disable-eee" = {
    description = "Disable Energy Efficient Ethernet on eno1 for Gigabit speed";
    wantedBy = [ "multi-user.target" ];
    after = [ "network.target" ];
    serviceConfig = {
      Type = "oneshot";
      ExecStart = "${pkgs.ethtool}/bin/ethtool --set-eee eno1 eee off";
      RemainAfterExit = true;
    };
  };
  # --- Мережа та Глобальний Швидкісний DNS (Заблоковано втручання DHCP) ---
  networking.nameservers = [ "1.1.1.1" "8.8.8.8" "1.0.0.1" ];
  networking.networkmanager.dns = "none";
  networking.resolvconf.enable = false;
  environment.etc."resolv.conf".text = ''
    nameserver 1.1.1.1
    nameserver 8.8.8.8
    options edns0
  '';

  # --- Tailscale VPN ---
  services.tailscale = {
    enable = true;
    useRoutingFeatures = "both"; # Дозволити маршрутизацію трафіку через Tailscale
  };

  # --- OpenSSH Server ---
  services.openssh = {
    enable = true;
    settings.PermitRootLogin = "yes";
  };

  # --- Друк CUPS та підтримка мережевого принтера HP LaserJet 2420n (192.168.66.10) ---
  services.printing = {
    enable = true;
    drivers = with pkgs; [ hplip gutenprint ];
  };

  services.avahi = {
    enable = true;
    nssmdns4 = true;
    openFirewall = true;
  };

  hardware.printers = {
    ensurePrinters = [
      {
        name = "HP_LaserJet_2420n";
        location = "Офісна Мережа (192.168.66.10)";
        description = "HP LaserJet 2420n Network Printer";
        deviceUri = "socket://192.168.66.10:9100";
        model = "drv:///hp/hpcups.drv/hp-laserjet_2420-pcl3.ppd";
      }
    ];
    ensureDefaultPrinter = "HP_LaserJet_2420n";
  };

  # --- Графічна служба входу в систему SDDM (Display Manager) ---
  services.displayManager.sddm = {
    enable = true;
    wayland.enable = true; # Запуск SDDM у Wayland-сесії
  };

  # Увімкнення графічних служб X11/Xwayland.
  services.xserver.enable = true;

  # Реєстрація сесії Niri у диспетчері дисплеїв.
  services.displayManager.sessionPackages = [ pkgs.niri ];

  # --- Увімкнення програм на рівні системи ---
  programs.steam.enable = true;  # Steam (додає правила брандмауера тощо)
  programs.niri.enable = true;   # Віконний менеджер Niri

  # --- Служби інтеграції для Thunar ---
  # Монтування флешок, смітник, ескізи зображень
  services.gvfs.enable = true;
  services.tumbler.enable = true;

  # --- Flatpak ---
  # Потрібно для Sober та інших flatpak-програм
  services.flatpak.enable = true;

  # --- Вимкнення жорсткого килера пам'яті (systemd-oomd) ---
  # Запобігає вильоту Discord та ігор (tModLoader / TBOI) при сплесках пам'яті
  systemd.oomd.enable = false;

  # --- Оптимізація вимкнення ПК та усунення зависань user@1000.service ---
  # Зменшує таймаут очікування з 90 секунд до 10 секунд
  systemd.settings.Manager = {
    DefaultTimeoutStopSec = "10s";
  };

  # Завершення фонових процесів Steam/Proton при вимкненні
  services.logind = {
    settings.Login = {
      KillUserProcesses = true;
      InhibitDelayMaxSec = 5;
      UserStopDelaySec = 5;
    };
  };

  # --- VMWare Workstation ---
  # Автоматично збирає модулі ядра vmmon/vmnet
  virtualisation.vmware.host.enable = true;

  # --- Waydroid ---
  # Емулятор Android для Wayland
  virtualisation.waydroid.enable = true;
  virtualisation.waydroid.package = pkgs.waydroid-nftables;

  # --- PipeWire: Сервер звуку та захоплення екрану ---
  # Потрібен для Discord screen sharing, OBS та EasyEffects
  services.pipewire = {
    enable = true;
    alsa.enable = true;        # Сумісність з ALSA-програмами
    alsa.support32Bit = true;  # 32-бітна сумісність (для Steam/Wine)
    pulse.enable = true;       # Сумісність з PulseAudio-програмами
  };

  # --- XDG Desktop Portal: Портали для захоплення екрану на Wayland ---
  # Без цього Discord, OBS та інші програми не можуть транслювати/записувати екран
  xdg.portal = {
    enable = true;
    extraPortals = with pkgs; [
      xdg-desktop-portal-gnome  # Портал для GNOME/GTK програм (Discord, Vivaldi тощо)
      xdg-desktop-portal-gtk    # Базовий GTK-портал (file picker, screen sharing)
    ];
    config = {
      common = {
        default = [ "gtk" ];
      };
      niri = {
        default = lib.mkForce [ "gnome" "gtk" ];
      };
    };
  };

  # --- Декларативні асоціації програм за замовчуванням (XDG MIME) ---
  xdg.mime = {
    enable = true;
    defaultApplications = {
      "text/html" = "chromium-browser.desktop";
      "x-scheme-handler/http" = "chromium-browser.desktop";
      "x-scheme-handler/https" = "chromium-browser.desktop";
      "x-scheme-handler/about" = "chromium-browser.desktop";
      "x-scheme-handler/unknown" = "chromium-browser.desktop";
      "x-scheme-handler/chrome" = "chromium-browser.desktop";
      "video/mp4" = "vlc.desktop";
      "video/mpeg" = "vlc.desktop";
      "video/quicktime" = "vlc.desktop";
      "video/webm" = "vlc.desktop";
      "video/x-matroska" = "vlc.desktop";
      "audio/mpeg" = "vlc.desktop";
      "audio/x-wav" = "vlc.desktop";
      "audio/ogg" = "vlc.desktop";
      "audio/flac" = "vlc.desktop";
    };
  };

  # --- nix-ld: Запуск немодифікованих бінарних файлів ---
  # Дозволяє запускати програми, скомпільовані для інших Linux-дистрибутивів
  programs.nix-ld.enable = true;
  programs.nix-ld.libraries = with pkgs; [
    # Цей набір бібліотек покриває 99% залежностей Electron-програм
    stdenv.cc.cc
    glib
    nspr
    nss
    atk
    at-spi2-atk
    cups
    dbus
    cairo
    gtk3
    pango
    libxkbcommon
    libx11
    libxcomposite
    libxdamage
    libxext
    libxfixes
    libxrandr
    libxcb
    mesa
    expat
    libgbm
    systemd
    alsa-lib
    at-spi2-core
    libudev0-shim # Часто рятує при помилці libudev.so.1
  ];

  # --- Стилізація QT ---
  qt = {
    enable = true;
    platformTheme = "gnome";
    style = "adwaita-dark";
  };

  # --- Системні змінні середовища ---
  environment.variables = {
    GTK_THEME = "Adwaita:dark"; # Темна тема GTK для всіх програм
    XCURSOR_THEME = "Deltarune-Dark-Cursors";
    XCURSOR_SIZE = "16";
  };

security.rtkit.enable = true;
}
