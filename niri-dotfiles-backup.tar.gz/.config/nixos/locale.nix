# Модуль локалізації та клавіатури.
# Тут налаштовується часовий пояс, системні мови та правила перемикання розкладок клавіатури.

{ config, pkgs, ... }:

{
  # Встановлення вашого часового поясу (Київ, Україна).
  time.timeZone = "Europe/Kyiv";

  # Головна системна мова інтерфейсу — українська.
  i18n.defaultLocale = "uk_UA.UTF-8";

  # Додаткові регіональні налаштування (формати дат, чисел, валюти тощо) — українські.
  i18n.extraLocaleSettings = {
    LC_ADDRESS = "uk_UA.UTF-8";
    LC_IDENTIFICATION = "uk_UA.UTF-8";
    LC_MEASUREMENT = "uk_UA.UTF-8";
    LC_MONETARY = "uk_UA.UTF-8";
    LC_NAME = "uk_UA.UTF-8";
    LC_NUMERIC = "uk_UA.UTF-8";
    LC_PAPER = "uk_UA.UTF-8";
    LC_TELEPHONE = "uk_UA.UTF-8";
    LC_TIME = "uk_UA.UTF-8";
  };

  # Налаштування розкладки клавіатури для X11 та Wayland (використовується greetd та Niri).
  services.xserver.xkb = {
    layout = "us,ua";                  # Дві розкладки: англійська (США) та українська
    variant = "";                      # Стандартні варіанти розкладки
    options = "grp:alt_shift_toggle";  # Перемикання мови класичним способом: Alt+Shift
  };

  # Синхронізація розкладки з віртуальними консолями (TTY),
  # щоб українська та англійська працювали і там.
  console.useXkbConfig = true;
}
