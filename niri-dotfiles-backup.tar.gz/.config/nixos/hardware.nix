# Модуль налаштування апаратного забезпечення.
# Тут налаштовуються драйвери відеокарти, Bluetooth, принтери та бездротові мережі.

{ config, pkgs, ... }:

{
  # Дозвіл на завантаження пропрієтарних прошивок для заліза (Wi-Fi, Bluetooth тощо).
  hardware.enableRedistributableFirmware = true;

  # Встановлення Wi-Fi регіону (країни) для розблокування 5 ГГц каналів (активне сканування)
  boot.extraModprobeConfig = ''
    options cfg80211 ieee80211_regdom=UA
  '';

  # --- Налаштування Bluetooth ---
  hardware.bluetooth = {
    enable = true;
    powerOnBoot = true; # Автоматично вмикати Bluetooth при старті системи
  };

  # Служба Blueman для графічного керування Bluetooth (іконка в треї та підключення пристроїв).
  services.blueman.enable = true;

  # --- Налаштування графіки та апаратного прискорення AMD GPU ---
  hardware.graphics = {
    enable = true; # Увімкнення OpenGL та Vulkan драйверів
    enable32Bit = true; # Ввімкнено підтримку 32-бітних драйверів для Steam / 32-бітних ігор

    # Додаткові пакети для апаратного прискорення декодування відео (VA-API) та OpenCL
    extraPackages = with pkgs; [
      libva-vdpau-driver # VDPAU бекенд для VA-API
      libvdpau-va-gl    # VDPAU драйвер через OpenGL
      rocmPackages.clr.icd # OpenCL драйвер для AMD (необхідний для DaVinci Resolve)
    ];
  };

  # --- Налаштування друку (HP LaserJet 2420dn) ---
  services.printing = {
    enable = true; # Увімкнення служби друку CUPS
    drivers = [ pkgs.hplip ]; # Драйвер HPLIP для принтерів HP
  };

  # Служба Avahi для автоматичного виявлення мережевих принтерів у вашій локальній мережі (mDNS/DNS-SD).
  services.avahi = {
    enable = true;
    nssmdns4 = true; # Дозволяє резолвити .local хости
    openFirewall = true; # Автоматично відкриває необхідні порти у брандмауері
  };
}
