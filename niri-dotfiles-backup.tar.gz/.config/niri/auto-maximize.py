#!/usr/bin/env python3
import glob
import json
import os
import queue
import socket
import subprocess
import sys
import threading
import time

def log(msg):
    print(f"[auto-maximize] {msg}", flush=True)

def find_socket():
    # Try NIRI_SOCKET env variable
    path = os.environ.get("NIRI_SOCKET")
    if path and os.path.exists(path):
        return path
    # Fallback to searching /run/user/1000/
    paths = glob.glob("/run/user/1000/niri*.sock")
    if paths:
        return paths[0]
    return None

def send_niri_request(req):
    socket_path = find_socket()
    if not socket_path:
        return None
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(0.5) # safety timeout to prevent deadlocks
        s.connect(socket_path)
        payload = json.dumps(req) + "\n"
        s.sendall(payload.encode("utf-8"))
        
        # Read reply (replies are single-line JSON)
        buffer = b""
        while b"\n" not in buffer:
            chunk = s.recv(4096)
            if not chunk:
                break
            buffer += chunk
        s.close()
        
        if not buffer:
            return None
        line = buffer.decode("utf-8").split("\n")[0]
        return json.loads(line)
    except Exception as e:
        log(f"Socket error: {e}")
        return None

def get_outputs():
    reply = send_niri_request("Outputs")
    if reply and "Ok" in reply and "Outputs" in reply["Ok"]:
        return reply["Ok"]["Outputs"]
    return {}

def get_workspaces():
    reply = send_niri_request("Workspaces")
    if reply and "Ok" in reply and "Workspaces" in reply["Ok"]:
        return reply["Ok"]["Workspaces"]
    return []

def get_windows():
    reply = send_niri_request("Windows")
    if reply and "Ok" in reply and "Windows" in reply["Ok"]:
        return reply["Ok"]["Windows"]
    return []

# Thread-safe queue for layout checks
layout_queue = queue.Queue()
known_app_ids = set()  # set of running app_ids to avoid focus fight on notifications/redraws
is_processing = False

def check_workspace_with_windows(ws_id, ws_windows, monitor_width, original_focused_id):
    global is_processing
    
    if is_processing:
        return

    count = len(ws_windows)
    if count == 0:
        return

    # Check if any window is maximized
    maximized_window = None
    for w in ws_windows:
        layout = w.get("layout", {})
        tile_size = layout.get("tile_size", [0, 0])
        tile_width = tile_size[0] if tile_size else 0
        if tile_width > (monitor_width * 0.9):
            maximized_window = w
            break

    is_processing = True
    try:
        if count == 1:
            if not maximized_window:
                log(f"Maximizing single window {ws_windows[0].get('id')} on workspace {ws_id}")
                # Focus the window first to ensure MaximizeColumn targets it
                send_niri_request({"Action": {"FocusWindow": {"id": ws_windows[0]["id"]}}})
                send_niri_request({"Action": {"MaximizeColumn": {}}})
                if original_focused_id and original_focused_id != ws_windows[0]["id"]:
                    send_niri_request({"Action": {"FocusWindow": {"id": original_focused_id}}})
        else:
            if maximized_window:
                log(f"Multiple windows detected on workspace {ws_id}. Unmaximizing window {maximized_window.get('id')}")
                # Focus maximized window, unmaximize, and restore focus
                send_niri_request({"Action": {"FocusWindow": {"id": maximized_window["id"]}}})
                send_niri_request({"Action": {"MaximizeColumn": {}}})
                if original_focused_id and original_focused_id != maximized_window["id"]:
                    send_niri_request({"Action": {"FocusWindow": {"id": original_focused_id}}})
    except Exception as e:
        log(f"Error during check_workspace: {e}")
    finally:
        is_processing = False

def run_layout_check():
    # Keep our known app IDs in sync (remove closed apps)
    try:
        current_windows = get_windows()
        if current_windows:
            current_apps = {w["app_id"] for w in current_windows if w.get("app_id")}
            known_app_ids.intersection_update(current_apps)
    except Exception:
        current_windows = []

    # Evaluate active workspaces on all monitors to support instant multi-monitor layouts
    try:
        workspaces = get_workspaces()
        outputs = get_outputs()
        
        # Find currently focused window to restore focus later
        original_focused_id = None
        for w in current_windows:
            if w.get("is_focused"):
                original_focused_id = w.get("id")
                break
        
        # Group windows by workspace_id
        ws_to_windows = {}
        for w in current_windows:
            ws_id = w.get("workspace_id")
            if ws_id is not None and not w.get("is_floating"):
                if ws_id not in ws_to_windows:
                    ws_to_windows[ws_id] = []
                ws_to_windows[ws_id].append(w)
        
        # Run checks on all visible (active) workspaces across all monitors
        for ws in workspaces:
            if ws.get("is_active"):
                ws_id = ws.get("id")
                output_name = ws.get("output")
                if ws_id is not None and output_name in outputs:
                    logical = outputs[output_name].get("logical", {})
                    width = logical.get("width", 1920)
                    ws_wins = ws_to_windows.get(ws_id, [])
                    check_workspace_with_windows(ws_id, ws_wins, width, original_focused_id)
    except Exception as e:
        log(f"Error checking workspaces: {e}")

def layout_worker():
    while True:
        try:
            # Wait for at least one task
            task = layout_queue.get()
            if task is None:
                break
            
            # Debounce: Sleep briefly to allow incoming events to pool
            time.sleep(0.05)
            
            # Drain queue
            while not layout_queue.empty():
                try:
                    layout_queue.get_nowait()
                    layout_queue.task_done()
                except queue.Empty:
                    break
            
            # Run single layout verification
            run_layout_check()
            layout_queue.task_done()
        except Exception as e:
            log(f"Error in layout worker: {e}")

def main():
    log("auto-maximize daemon starting up...")
    time.sleep(0.1) # brief sleep for socket availability
    
    # Initialize running app IDs
    try:
        initial_windows = get_windows()
        for w in initial_windows:
            app_id = w.get("app_id")
            if app_id:
                known_app_ids.add(app_id)
        log(f"Initial running apps: {known_app_ids}")
    except Exception as e:
        log(f"Error during initialization: {e}")

    # Start layout worker thread to prevent IPC deadlocks
    worker = threading.Thread(target=layout_worker, daemon=True)
    worker.start()

    # Run once at startup
    layout_queue.put("check")

    # Listen to event-stream via UNIX socket directly (resolves OS pipe buffering delays)
    socket_path = find_socket()
    if not socket_path:
        log("Could not find Niri IPC socket!")
        sys.exit(1)

    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.connect(socket_path)
        s.sendall(b"\"EventStream\"\n")
        
        # Wrap socket in a file interface for instant, unbuffered, line-by-line reading
        f = s.makefile("r", encoding="utf-8")
        
        # Read the confirmation line {"Ok":"Handled"}
        f.readline()
        
        while True:
            line = f.readline()
            if not line:
                break
            
            # Switch view to workspace dynamically ONLY when a brand NEW app is launched and focused on the active monitor
            if "WindowOpenedOrChanged" in line:
                try:
                    data = json.loads(line)
                    window = data["WindowOpenedOrChanged"]["window"]
                    app_id = window.get("app_id")
                    if app_id and window.get("is_focused") and not window.get("is_floating"):
                        if app_id not in known_app_ids:
                            known_app_ids.add(app_id)
                            ws_id = window.get("workspace_id")
                            if ws_id is not None:
                                # Fetch workspaces to see if new window is on the active monitor
                                workspaces = get_workspaces()
                                active_output = None
                                target_output = None
                                for ws in workspaces:
                                    if ws.get("is_focused"):
                                        active_output = ws.get("output")
                                    if ws.get("id") == ws_id:
                                        target_output = ws.get("output")
                                
                                if active_output and active_output == target_output:
                                    log(f"New app '{app_id}' launched on active monitor {active_output}. Switching workspace to {ws_id}.")
                                    send_niri_request({"Action": {"FocusWorkspace": {"reference": {"Id": ws_id}}}})
                                else:
                                    log(f"New app '{app_id}' launched on inactive monitor {target_output}. Ignoring focus jump.")
                except Exception as e:
                    log(f"Error parsing WindowOpenedOrChanged: {e}")

            # Trigger layout checks ONLY on WindowsChanged and WorkspaceActivated to prevent CPU spikes / socket disconnects
            if any(ev in line for ev in ["WindowsChanged", "WorkspaceActivated"]):
                layout_queue.put("check")
    except KeyboardInterrupt:
        log("auto-maximize daemon exiting on KeyboardInterrupt.")
        sys.exit(0)
    except Exception as e:
        log(f"auto-maximize daemon crashed: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
