#!/usr/bin/env python3
import glob
import json
import os
import socket
import sys
import time

STATE_FILE = "/run/user/1000/workspace-helper-state.json"

def find_socket():
    # Try NIRI_SOCKET env variable
    path = os.environ.get("NIRI_SOCKET")
    if path and os.path.exists(path):
        return path
    # Fallback to searching /run/user/1000/
    paths = glob.glob("/run/user/1000/niri*.sock")
    if paths:
        return paths[0]
    return None

def send_niri_request(req):
    socket_path = find_socket()
    if not socket_path:
        return None
    try:
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.connect(socket_path)
        payload = json.dumps(req) + "\n"
        s.sendall(payload.encode("utf-8"))
        
        # Read reply
        buffer = b""
        while b"\n" not in buffer:
            chunk = s.recv(4096)
            if not chunk:
                break
            buffer += chunk
        s.close()
        
        if not buffer:
            return None
        line = buffer.decode("utf-8").split("\n")[0]
        return json.loads(line)
    except Exception:
        return None

def read_state():
    try:
        if os.path.exists(STATE_FILE):
            with open(STATE_FILE, "r") as f:
                return json.load(f)
    except Exception:
        pass
    return None

def write_state(state):
    try:
        with open(STATE_FILE, "w") as f:
            json.dump(state, f)
    except Exception:
        pass

def main():
    if len(sys.argv) < 2:
        return
    action = sys.argv[1] # "focus", "move", "scroll-down", "scroll-up"
    
    # Query workspaces list
    reply = send_niri_request("Workspaces")
    if not reply or "Ok" not in reply or "Workspaces" not in reply["Ok"]:
        return
    workspaces = reply["Ok"]["Workspaces"]

    # Find currently focused workspace and active output
    focused_ws_id = None
    active_output = "DP-1"
    for ws in workspaces:
        if ws.get("is_focused"):
            focused_ws_id = ws.get("id")
            active_output = ws.get("output")
            break

    if action in ["focus", "move"]:
        if len(sys.argv) < 3:
            return
        num = int(sys.argv[2])
        
        current_time = time.time()
        state = read_state()
        
        is_double_press = False
        if state:
            last_time = state.get("time", 0)
            last_num = state.get("num", 0)
            # Detect double press (within 400ms on the same key)
            if current_time - last_time < 0.4 and last_num == num:
                is_double_press = True

        # Target output resolution
        if is_double_press:
            # Toggle to the other monitor than what we targeted last time
            last_monitor = state.get("monitor", "DP-1")
            target_output = "HDMI-A-1" if last_monitor == "DP-1" else "DP-1"
        else:
            # Single press: use currently active monitor
            target_output = active_output

        # Calculate target workspace ID
        if target_output == "HDMI-A-1":
            target = num + 4
        else:
            target = num

        # Save state
        write_state({
            "time": current_time,
            "monitor": target_output,
            "num": num
        })

        if action == "focus":
            send_niri_request({"Action": {"FocusWorkspace": {"reference": {"Id": target}}}})
        elif action == "move":
            send_niri_request({"Action": {"MoveColumnToWorkspace": {"reference": {"Id": target}}}})

    elif action in ["scroll-down", "scroll-up"]:
        if focused_ws_id is None:
            return
        
        # We assume workspaces 1-4 are DP-1, and 5-8 are HDMI-A-1
        is_dp1 = focused_ws_id in [1, 2, 3, 4]
        is_hdmi = focused_ws_id in [5, 6, 7, 8]
        
        if not is_dp1 and not is_hdmi:
            # Fallback if focus is on a dynamic workspace
            if active_output == "HDMI-A-1":
                focused_ws_id = 5
                is_hdmi = True
            else:
                focused_ws_id = 1
                is_dp1 = True

        if action == "scroll-down":
            if is_dp1:
                target = (focused_ws_id - 1 + 1) % 4 + 1
            else:
                target = (focused_ws_id - 5 + 1) % 4 + 5
        else: # scroll-up
            if is_dp1:
                target = (focused_ws_id - 1 - 1 + 4) % 4 + 1
            else:
                target = (focused_ws_id - 5 - 1 + 4) % 4 + 5

        send_niri_request({"Action": {"FocusWorkspace": {"reference": {"Id": target}}}})

if __name__ == "__main__":
    main()
