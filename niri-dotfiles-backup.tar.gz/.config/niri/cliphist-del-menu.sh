#!/bin/sh
# Clipboard history wofi deletion selector
SELECTED=$(cliphist list | wofi --dmenu --prompt "Виберіть елемент для видалення:")
if [ -n "$SELECTED" ]; then
    echo "$SELECTED" | cliphist delete
fi
