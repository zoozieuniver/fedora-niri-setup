#!/bin/sh
# Clipboard history wofi selector
cliphist list | wofi --dmenu | cliphist decode | wl-copy
