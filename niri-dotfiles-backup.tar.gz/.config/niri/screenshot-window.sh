#!/bin/sh
# Screenshot the focused window using Niri's native action and open in satty
BEFORE_FILE=$(mktemp)
ls -1 ~/Pictures/Screenshots > "$BEFORE_FILE" 2>/dev/null

# Trigger Niri's native screenshot-window action
niri msg action screenshot-window

# Wait a brief moment for the file to be written
sleep 0.3

# Find the newly created file
AFTER_FILE=$(mktemp)
ls -1 ~/Pictures/Screenshots > "$AFTER_FILE" 2>/dev/null

NEW_FILE=$(comm -13 "$BEFORE_FILE" "$AFTER_FILE" | head -n 1)

rm -f "$BEFORE_FILE" "$AFTER_FILE"

if [ -n "$NEW_FILE" ]; then
    FILE_PATH="$HOME/Pictures/Screenshots/$NEW_FILE"
    satty --filename "$FILE_PATH"
else
    echo "No new screenshot file found."
fi
