use crate::gui::SoundpadGui;
use egui::Ui;
use egui_material_icons::icons::*;

mod body;
mod footer;
mod header;
mod hotkey_capture;
mod hotkeys;
mod settings;
mod waiting_for_daemon;

impl SoundpadGui {
    pub(crate) fn get_volume_icon(volume: f32) -> &'static str {
        if volume > 0.7 {
            ICON_VOLUME_UP.codepoint
        } else if volume <= 0.0 {
            ICON_VOLUME_OFF.codepoint
        } else if volume < 0.3 {
            ICON_VOLUME_MUTE.codepoint
        } else {
            ICON_VOLUME_DOWN.codepoint
        }
    }

    pub fn draw(&mut self, ui: &mut Ui) {
        self.draw_header(ui);
        self.draw_body(ui);
        ui.separator();
        self.draw_footer(ui);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_get_volume_icon() {
        assert_eq!(SoundpadGui::get_volume_icon(0.8), ICON_VOLUME_UP.codepoint);
        assert_eq!(SoundpadGui::get_volume_icon(0.0), ICON_VOLUME_OFF.codepoint);
        assert_eq!(
            SoundpadGui::get_volume_icon(-0.1),
            ICON_VOLUME_OFF.codepoint
        );
        assert_eq!(
            SoundpadGui::get_volume_icon(0.2),
            ICON_VOLUME_MUTE.codepoint
        );
        assert_eq!(
            SoundpadGui::get_volume_icon(0.5),
            ICON_VOLUME_DOWN.codepoint
        );

        // Masters go past 100%, which must not fall off the top of the ladder.
        assert_eq!(SoundpadGui::get_volume_icon(1.0), ICON_VOLUME_UP.codepoint);
        assert_eq!(SoundpadGui::get_volume_icon(2.0), ICON_VOLUME_UP.codepoint);
    }
}
